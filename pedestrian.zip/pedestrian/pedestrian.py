# Import necessary libraries
import cv2
import numpy as np
from ultralytics import YOLO

# Load YOLOv8 models for vehicle and pedestrian detection
vehicle_model = YOLO("yolov8m.pt")  # Adjust model name as needed
pedestrian_model = YOLO("yolov8m.pt")  # Use the same or a specific pedestrian model

# Initialize video capture
cap = cv2.VideoCapture("E:\Downloads\Pedestrian on roads_ Being cautious is the key to safety __ Cyberabad Traffic Police - Cyberabad Traffic Police (240p, h264, youtube).mp4")  # Replace 'video.mp4' with your video source

# Define ROI (Region of Interest) coordinates
roi_top_left = (100, 100)
roi_bottom_right = (500, 500)

# Distance threshold for collision warning
distance_threshold = 50  # Set this value based on experiment or pixel scaling

# Define the output size (smaller resolution)
output_width = 640
output_height = 360

# Confidence threshold for object detection
confidence_threshold = 0.5  # Adjust based on your requirements (0.5 is a good default)

# Main loop
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Capture current frame's ROI
    roi = frame[roi_top_left[1]:roi_bottom_right[1], roi_top_left[0]:roi_bottom_right[0]]

    # Detect vehicles
    vehicle_results = vehicle_model.predict(roi, conf=confidence_threshold)  # Set confidence threshold
    vehicle_boxes = vehicle_results[0].boxes.xyxy.cpu().numpy()  # Bounding boxes for vehicles

    # Detect pedestrians
    pedestrian_results = pedestrian_model.predict(roi, conf=confidence_threshold)  # Set confidence threshold
    pedestrian_boxes = pedestrian_results[0].boxes.xyxy.cpu().numpy()  # Bounding boxes for pedestrians

    # Check each detected vehicle and pedestrian for potential collision
    collision_warning = False
    for vehicle_box in vehicle_boxes:
        for pedestrian_box in pedestrian_boxes:
            # Calculate distance between the centers of the vehicle and pedestrian bounding boxes
            vehicle_center = ((vehicle_box[0] + vehicle_box[2]) / 2, (vehicle_box[1] + vehicle_box[3]) / 2)
            pedestrian_center = ((pedestrian_box[0] + pedestrian_box[2]) / 2, (pedestrian_box[1] + pedestrian_box[3]) / 2)
            distance = np.sqrt((vehicle_center[0] - pedestrian_center[0]) ** 2 + (vehicle_center[1] - pedestrian_center[1]) ** 2)

            if distance < distance_threshold:
                collision_warning = True
                # Draw alert box around detected objects
                cv2.rectangle(roi, (int(vehicle_box[0]), int(vehicle_box[1])), (int(vehicle_box[2]), int(vehicle_box[3])), (0, 0, 255), 2)
                cv2.rectangle(roi, (int(pedestrian_box[0]), int(pedestrian_box[1])), (int(pedestrian_box[2]), int(pedestrian_box[3])), (0, 0, 255), 2)

    # Draw bounding boxes for vehicles
    for box in vehicle_boxes:
        cv2.rectangle(roi, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])), (255, 0, 0), 2)

    # Draw bounding boxes for pedestrians
    for box in pedestrian_boxes:
        cv2.rectangle(roi, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])), (0, 255, 0), 2)

    # If collision warning, display warning alert on frame
    if collision_warning:
        cv2.putText(frame, "Collision Warning!", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    # Resize the frame to the desired output size
    resized_frame = cv2.resize(frame, (output_width, output_height))

    # Display processed frame
    cv2.imshow("Collision Warning System", resized_frame)

    # Check for exit condition (e.g., 'q' key)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release video capture and destroy all OpenCV windows
cap.release()
cv2.destroyAllWindows()

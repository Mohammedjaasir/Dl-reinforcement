import cv2
import numpy as np

# Open the video file using the corrected file path
vidcap = cv2.VideoCapture(r"E:\backup\Downloads\Hackathon\lane\LaneVideo.mp4")  # Update to the exact file name

if not vidcap.isOpened():
    print("Error: Could not open video.")
    exit()

success, image = vidcap.read()

def nothing(x):
    pass

# Create a window named "Trackbars"
cv2.namedWindow("Trackbars")

# Create the trackbars
cv2.createTrackbar("L - H", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("L - S", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("L - V", "Trackbars", 0, 255, nothing)
cv2.createTrackbar("U - H", "Trackbars", 255, 255, nothing)
cv2.createTrackbar("U - S", "Trackbars", 255, 255, nothing)
cv2.createTrackbar("U - V", "Trackbars", 255, 255, nothing)

frame_count = 0

while success:
    frame_count += 1
    success, image = vidcap.read()
    if not success:
        print("Error: Could not read frame.")
        break
    
    frame = cv2.resize(image, (640, 480))

    # Your lane detection code here...
    # [Omitted for brevity]

    # Display the various stages of lane detection
    cv2.imshow("Original", frame)
    
    # Show the other processed images as needed
    # cv2.imshow("Bird's Eye View", transformed_frame)
    # cv2.imshow("Lane Detection - Image Thresholding", mask)
    # cv2.imshow("Lane Detection - Sliding Windows", msk)

    # Exit if the 'ESC' key is pressed
    if cv2.waitKey(10) == 27:
        break

print(f"Total frames processed: {frame_count}")

# Release the video capture object and close all windows
vidcap.release()
cv2.destroyAllWindows()
